package com.ejemplo.tareas.service;

import com.ejemplo.tareas.exception.ConflictoException;
import com.ejemplo.tareas.exception.RecursoNoEncontradoException;
import com.ejemplo.tareas.exception.ReglaNegocioException;
import com.ejemplo.tareas.model.Tarea;
import com.ejemplo.tareas.repository.TareaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TareaService {

    private final TareaRepository repository;

    public TareaService(TareaRepository repository) {
        this.repository = repository;
    }

    /** El filtro por estado se resuelve aqui, no en el Controller. */
    public List<Tarea> listar(Boolean completada) {
        if (completada == null) {
            return repository.findAll();
        }
        return repository.findByCompletada(completada);
    }

    public Tarea buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe una tarea con id " + id));
    }

    public Tarea crear(Tarea tarea) {
        validarTitulo(tarea.getTitulo());
        tarea.setId(null);
        tarea.setCompletada(false); // siempre nace sin completar
        return repository.save(tarea);
    }

    public Tarea actualizar(Long id, Tarea datos) {
        Tarea existente = buscarPorId(id);
        validarTitulo(datos.getTitulo());
        existente.setTitulo(datos.getTitulo());
        existente.setDescripcion(datos.getDescripcion());
        return existente;
    }

    public Tarea completar(Long id) {
        Tarea tarea = buscarPorId(id);
        if (tarea.isCompletada()) {
            throw new ConflictoException("La tarea " + id + " ya esta completada");
        }
        tarea.setCompletada(true);
        return tarea;
    }

    /**
     * Decision documentada: SE PERMITE eliminar tareas completadas
     * (eliminar equivale a limpiar el historial).
     */
    public void eliminar(Long id) {
        if (!repository.deleteById(id)) {
            throw new RecursoNoEncontradoException("No existe una tarea con id " + id);
        }
    }

    private void validarTitulo(String titulo) {
        if (titulo == null || titulo.trim().isEmpty()) {
            throw new ReglaNegocioException("El titulo es obligatorio y no puede estar vacio");
        }
    }
}

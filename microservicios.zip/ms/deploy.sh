#!/usr/bin/env bash
# Compila ambos microservicios y los deja corriendo en segundo plano.
set -e
cd "$(dirname "$0")"
for s in productos tareas; do
  (cd $s && mvn -q clean package -DskipTests)
  pkill -f "$s-0.0.1-SNAPSHOT.jar" 2>/dev/null || true
  nohup java -jar $s/target/$s-0.0.1-SNAPSHOT.jar > $s.log 2>&1 &
  echo "$s iniciado (log: $s.log)"
done

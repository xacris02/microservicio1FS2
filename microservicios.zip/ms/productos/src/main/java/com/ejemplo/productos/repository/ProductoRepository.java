package com.ejemplo.productos.repository;

import com.ejemplo.productos.model.Producto;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

/** Repositorio simulado: la lista en memoria es el unico "almacen de datos". */
@Repository
public class ProductoRepository {

    private final List<Producto> productos = new ArrayList<>();
    private final AtomicLong contadorId = new AtomicLong(1);

    public List<Producto> findAll() {
        return new ArrayList<>(productos); // copia defensiva
    }

    public Optional<Producto> findById(Long id) {
        return productos.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
    }

    public Producto save(Producto p) {
        if (p.getId() == null) {
            p.setId(contadorId.getAndIncrement());
            productos.add(p);
        }
        return p;
    }

    public boolean deleteById(Long id) {
        return productos.removeIf(p -> p.getId().equals(id));
    }
}

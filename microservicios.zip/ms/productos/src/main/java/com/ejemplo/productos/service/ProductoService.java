package com.ejemplo.productos.service;

import com.ejemplo.productos.exception.RecursoNoEncontradoException;
import com.ejemplo.productos.exception.ReglaNegocioException;
import com.ejemplo.productos.model.Producto;
import com.ejemplo.productos.repository.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoService {

    private final ProductoRepository repository;

    public ProductoService(ProductoRepository repository) {
        this.repository = repository;
    }

    public List<Producto> listar() {
        return repository.findAll();
    }

    public Producto buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe un producto con id " + id));
    }

    public Producto crear(Producto producto) {
        validar(producto);
        producto.setId(null);
        return repository.save(producto);
    }

    public Producto actualizar(Long id, Producto datos) {
        Producto existente = buscarPorId(id);
        validar(datos);
        existente.setNombre(datos.getNombre());
        existente.setPrecio(datos.getPrecio());
        existente.setStock(datos.getStock());
        return existente;
    }

    public void eliminar(Long id) {
        if (!repository.deleteById(id)) {
            throw new RecursoNoEncontradoException("No existe un producto con id " + id);
        }
    }

    // Reglas de negocio
    private void validar(Producto p) {
        if (p.getNombre() == null || p.getNombre().trim().isEmpty()) {
            throw new ReglaNegocioException("El nombre no puede estar vacio");
        }
        if (p.getPrecio() == null || p.getPrecio() <= 0) {
            throw new ReglaNegocioException("El precio debe ser mayor que 0");
        }
        if (p.getStock() == null || p.getStock() < 0) {
            throw new ReglaNegocioException("El stock no puede ser negativo");
        }
    }
}

# Casos microservicios con repositorio simulado

Dos microservicios Spring Boot (Java 17, Maven) con patron Controller-Service-Repository
y una `List` en memoria como repositorio. No usan base de datos ni se comunican entre si.

| Servicio  | Puerto | Base de la API  |
|-----------|--------|-----------------|
| productos | 8081   | /api/productos  |
| tareas    | 8082   | /api/tareas     |

Decision documentada (tareas): SE PERMITE eliminar una tarea completada.
Aviso: al ser en memoria, los datos se pierden cuando el servicio se reinicia.

## Ejecutar en local
    cd productos && mvn spring-boot:run      # o ./mvnw si lo generas con Initializr
    cd tareas    && mvn spring-boot:run

## Despliegue en AWS EC2 (Ubuntu)

### 1. Instancia y Security Group
- AMI Ubuntu 22.04/24.04, t2.micro o t3.micro.
- Inbound rules: SSH (22) desde tu IP, TCP 8081 y TCP 8082 (0.0.0.0/0 o tu IP).

### 2. Instalar Java y Maven en la instancia
    ssh -i clave.pem ubuntu@IP_PUBLICA
    sudo apt update && sudo apt install -y openjdk-17-jdk maven

### 3. Subir el proyecto (desde tu PC)
    scp -i clave.pem microservicios.zip ubuntu@IP_PUBLICA:~
    # en la instancia:
    sudo apt install -y unzip && unzip microservicios.zip && cd ms

### 4. Compilar y ejecutar
    ./deploy.sh

### 5. Probar (desde tu PC)
    curl http://IP_PUBLICA:8081/api/productos
    curl -X POST http://IP_PUBLICA:8081/api/productos -H "Content-Type: application/json" \
         -d '{"nombre":"Mouse","precio":9990,"stock":10}'
    curl http://IP_PUBLICA:8081/api/productos/99          # 404
    curl -X POST http://IP_PUBLICA:8082/api/tareas -H "Content-Type: application/json" \
         -d '{"titulo":"Estudiar","descripcion":"Spring Boot"}'
    curl -X PATCH http://IP_PUBLICA:8082/api/tareas/1/completar   # 200
    curl -X PATCH http://IP_PUBLICA:8082/api/tareas/1/completar   # 409
    curl "http://IP_PUBLICA:8082/api/tareas?completada=true"

### 6. (Opcional) Dejarlos como servicios
    sudo cp systemd/*.service /etc/systemd/system/
    sudo systemctl daemon-reload
    sudo systemctl enable --now productos tareas
    sudo systemctl status productos tareas
